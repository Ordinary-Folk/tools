OF KBar icons

One icon per OF script, the same tiles as tools.ordinary.co/scripts.
KBar 3: edit a button > Icon > Image > pick the PNG (or SVG). The mono folder has the
same glyphs in light grey on transparent for a monochrome toolbar.
